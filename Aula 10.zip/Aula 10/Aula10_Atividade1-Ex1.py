#1 - Faça um programa, utilizando while, que mostre na tela os números de 0 a 1000.

numero = 0

while numero <= 1000:
    print(numero)
    numero += 1