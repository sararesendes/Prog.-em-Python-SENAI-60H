# palavra reservada condicao
# loop finito
import time 


# iterando percorrendo 
# repetições 


l =  [1,2,3,4]


for i in range(10):
    produto = input('Digite o id do produto') 
    if i == 5:
        break